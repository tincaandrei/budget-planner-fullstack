import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import Login from './login/Login';
import AddUser from './user/AddUser';
import EditUserWrapper from './user/EditUserWrapper';
import UserList from './user/UserList';
import Dashboard from './dashboard/Dashboard';


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/users/new" element={<AddUser />} />
        <Route path="/users" element={<UserList />} />
        <Route path="/users/edit/:id" element={<EditUserWrapper />} />
        <Route path='/dashboard' element={<Dashboard/>}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;