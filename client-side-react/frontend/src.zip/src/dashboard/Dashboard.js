import React from "react";
import axiosInstance from "../helper/axios";
import BudgetCard from "./BudgetCard";
import { Container, Row, Col } from "react-bootstrap";
import AddTransactionModal from "../transactions/AddTransaction";

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            budgets: [],
            userName: localStorage.getItem("USER_NAME") || ""
        };
    }

    componentDidMount() {
        const userId = localStorage.getItem("USER_ID");
        if (!userId) return;

        axiosInstance.get(`/budgets/user/${userId}`)
            .then(res => {
                console.log("Received budgets:", res.data);
                this.setState({ budgets: res.data });
            })

            .catch(err => console.error("Error loading budgets", err));
    }

    handleAddTransaction = (data, type) => {
        const userId = localStorage.getItem("USER_ID");
        const budget = this.state.budgets[0]; // pick the first budget for now

        const url = type === "income"
            ? `/incomes/${budget.id}`
            : `/expenses/${budget.id}`;
        console.log("Sending to backend:", type, data);

        axiosInstance.post(url, data)
            .then(() => window.location.reload())
            .catch(err => {
                console.error("Error adding transaction:", err);
                alert("Something went wrong.");
            });
    };

    render() {
        return (
            <>
                <Container className="mt-4">
                    <h2 className="mb-4">Your budget, {this.state.userName} </h2>
                    <div className="d-flex justify-content-end mb-3">
                        <button
                            className="btn btn-success me-2"
                            onClick={() => this.setState({ showIncomeModal: true })}
                        >
                            + Add Income
                        </button>
                        <button
                            className="btn btn-danger"
                            onClick={() => this.setState({ showExpenseModal: true })}
                        >
                            - Add Expense
                        </button>
                    </div>
                    <Row>
                        {this.state.budgets.map(budget => (
                            <Col md={6} lg={4} key={budget.id}>
                                <BudgetCard budget={budget} />
                            </Col>
                        ))}
                    </Row>
                </Container>
                <AddTransactionModal
                    show={this.state.showIncomeModal}
                    type="income"
                    onClose={() => this.setState({ showIncomeModal: false })}
                    onSubmit={(data) => this.handleAddTransaction(data, "income")}
                />

                <AddTransactionModal
                    show={this.state.showExpenseModal}
                    type="expense"
                    onClose={() => this.setState({ showExpenseModal: false })}
                    onSubmit={(data) => this.handleAddTransaction(data, "expense")}
                />
            </>
        );
    }
}

export default Dashboard;
