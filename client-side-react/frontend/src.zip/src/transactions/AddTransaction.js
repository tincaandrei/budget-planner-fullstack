import React from "react";
import { Modal, Button, Form } from "react-bootstrap";

class AddTransactionModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            amount: "",
            description: "",
            date: "",
            categoryName: ""
        };
    }

    handleChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    handleSubmit = (e) => {
        e.preventDefault();

        const { amount, description, date, categoryName } = this.state;
        const { type, onSubmit } = this.props;

        if (!amount || !description || !date || !categoryName) {
            alert("Please fill in all fields.");
            return;
        }

        const payload = {
            amount: parseFloat(amount),
            description,
            date,
            category: {
                name: categoryName,
                type: type.toUpperCase()
            }
        };
        console.log("Submitting transaction:", payload);

        onSubmit(payload);
        this.setState({ amount: "", description: "", date: "", categoryName: "" });
    }

    render() {
        const { show, onClose, type } = this.props;
        const title = type === "income" ? "Add Income" : "Add Expense";

        return (
            <Modal show={show} onHide={onClose}>
                <Modal.Header closeButton>
                    <Modal.Title>{title}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={this.handleSubmit}>
                        <Form.Group className="mb-3">
                            <Form.Label>Amount</Form.Label>
                            <Form.Control type="number" name="amount" value={this.state.amount} onChange={this.handleChange} required />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Description</Form.Label>
                            <Form.Control name="description" value={this.state.description} onChange={this.handleChange} required />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Date</Form.Label>
                            <Form.Control type="date" name="date" value={this.state.date} onChange={this.handleChange} required />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Category</Form.Label>
                            <Form.Select name="categoryName" value={this.state.categoryName} onChange={this.handleChange} required>
                                <option value="">-- Choose a category --</option>
                                {type.toLowerCase() === "income" ? (
                                    <>
                                        <option value="Salary">Salary</option>
                                        <option value="Bonus">Bonus</option>
                                        <option value="Freelance">Freelance</option>
                                    </>

                                ) : (
                                    <>
                                        <option value="Housing">Housing</option>
                                        <option value="Food">Food</option>
                                        <option value="Transport">Transport</option>
                                        <option value="Vacation">Vacation</option>
                                        <option value="Car fuel">Car fuel</option>
                                        <option value="Entertainment">Entertainment</option>
                                    </>
                                )}
                            </Form.Select>
                        </Form.Group>
                        <div className="text-end">
                            <Button variant="secondary" onClick={onClose} className="me-2">Cancel</Button>
                            <Button variant="primary" type="submit">Save</Button>
                        </div>
                    </Form>
                </Modal.Body>
            </Modal>
        );
    }
}

export default AddTransactionModal;
