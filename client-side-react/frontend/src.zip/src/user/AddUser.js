import React from "react";
import axiosInstance from "../helper/axios";
import { Button, Container, Form } from "react-bootstrap";

class AddUser extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      email: ""
    };
  }

  handleInput = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { name, email } = this.state;

    if (!name || !email) {
      alert("Please fill in all fields.");
      return;
    }

    axiosInstance.post("/users", {
      name,
      email,
      budgets: []
    })
    .then(() => {
      window.location.href = "/";
    })
    .catch(err => {
      console.error("Error adding user:", err);
    });
  }

  render() {
    return (
      <Container className="mt-4">
        <h2>Add User</h2>
        <Form onSubmit={this.handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Name</Form.Label>
            <Form.Control
              name="name"
              value={this.state.name}
              onChange={this.handleInput}
              placeholder="Enter name"
              required
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              name="email"
              value={this.state.email}
              onChange={this.handleInput}
              placeholder="Enter email"
              required
            />
          </Form.Group>

          <Button variant="success" type="submit">Save User</Button>
        </Form>
      </Container>
    );
  }
}

export default AddUser;
