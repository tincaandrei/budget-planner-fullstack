import React from "react";
import axiosInstance from "../helper/axios";
import { Table, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

class UserList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      users: []
    };
  }

  componentDidMount() {
    axiosInstance.get("/users")
      .then(res => {
        this.setState({ users: res.data });
      })
      .catch(err => {
        console.error("Error loading users:", err);
      });
  }

  handleDelete = (id) => {
    axiosInstance.delete(`/users/${id}`)
      .then(() => {
        this.setState(prev => ({
          users: prev.users.filter(user => user.id !== id)
        }));
      })
      .catch(err => {
        console.error("Error deleting user:", err);
      });
  }

  render() {
    return (
      <div className="container mt-4">
        <h2>User Management</h2>
        <Link to="/users/new" className="btn btn-primary mb-3">+ Add New User</Link>
        <Table bordered hover>
          <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Actions</th></tr></thead>
          <tbody>
            {this.state.users.map(user => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>
                  <Link to={`/users/edit/${user.id}`} className="btn btn-sm btn-outline-primary me-2">Edit</Link>
                  <Button variant="outline-danger" size="sm" onClick={() => this.handleDelete(user.id)}>Delete</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    );
  }
}

export default UserList;
