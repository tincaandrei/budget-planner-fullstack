package com.login.service.impl;

import com.login.dto.AuthDTO;
import com.login.model.User;
import com.login.repository.UserRepository;
import org.springframework.stereotype.Component;
import com.login.service.AuthService;

import java.util.NoSuchElementException;

@Component
public class AuthServiceImpl implements AuthService {
    private final UserRepository userRepository;

    public AuthServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User login(AuthDTO auth) {
        User user = userRepository.findByUsernameAndPassword(auth.getUsername(), auth.getPassword());
        if (user == null) {
            throw new NoSuchElementException("User not found");
        }
        return user;
    }
}
