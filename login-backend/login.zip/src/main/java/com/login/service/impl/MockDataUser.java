package com.login.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.login.model.User;
import com.login.repository.UserRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

@Component
public class MockDataUser {

    private final UserRepository userRepository;

    public MockDataUser(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostConstruct
    public void init() {
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("users.json")) {
            ObjectMapper objectMapper = new ObjectMapper();
            List<User> users = Arrays.asList(objectMapper.readValue(is, User[].class));
            userRepository.saveAll(users);
            System.out.println(" Loaded users from JSON: " + users.size());
        } catch (Exception e) {
            throw new RuntimeException(" Failed to load mock-users.json", e);
        }
    }
}
